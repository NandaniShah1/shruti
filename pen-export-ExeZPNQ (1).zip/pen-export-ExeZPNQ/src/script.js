function myFunction(){
  //alert("thanks for visiting!!")
 let header=
     (document.getElementById ("header").style.color="blue");
}